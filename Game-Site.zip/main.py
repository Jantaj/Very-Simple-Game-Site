import code
import rps

print("----- Jantaj's Game Site -----")
h_rps = int(
    input("""
Do you want to play Hangman or Rock, Paper, Scissors?
[Type 1 for Hangman / Type 2 for RPS]: """))

end_code = False

while not end_code:
    if h_rps == 0:
        end_code = True
    if h_rps == 1:
        while True:
            code.script()
            again = input("Would you like to play again? (Yes/No): ")
            if again.lower() == "yes" or again.lower() == "ye" or again.lower(
            ) == "yh" or again.lower() == "y":
                continue
            elif again.lower() == "no":
                play_tic = input(
                    "Do you want to play Rock Paper Scissors Instead? (Yes/No): "
                ).lower()
                if play_tic == "yes":
                    h_rps = 2
                    break
                elif play_tic == "no":
                    h_rps = 0
                    print("Thank you for playing.")
                    break
                else:
                    h_rps = 0
                    print("Invalid Input")
                    break
            else:
                h_rps = 0
                print("Invalid Input")
                break

    if h_rps == 2:
        while True:
            rps.rps_code()
            if h_rps == 1:
                break
            play_tic_again = input(
                "Do you want to play again? [Yes/No]: ").lower()
            if play_tic_again == "yes" or play_tic_again == "ye" or play_tic_again == "yh" or play_tic_again == "y":
                continue
            elif play_tic_again == "no":
                play_h = input(
                    "Do you want to play Hangman instead? [Yes/No]: ")
                if play_h.lower() == "yes":
                    h_rps = 1
                    break
                elif play_h.lower() == "no":
                    h_rps = 0
                    print("Thank you for playing.")
                    break
                else:
                    h_rps = 0
                    print("Invalid Input")
                    break
            else:
                h_rps = 0
                print("Invalid Input")
                break
