def script():
    import random
    import stages
    import words

    print(stages.logo)
    chosen_word = random.choice(words.word)
    word_length = len(chosen_word)
    lives = 6
    print(f'Pssst, the solution is {chosen_word}.')

    display = []

    for _ in range(word_length):
        display += "_"
    game_end = False
    all_guesses = ""
    while not game_end:
        guess = input("Guess a letter: ").lower()
        all_guesses += guess + ","
        right_guess = 0
        for position in range(word_length):
            letter = chosen_word[position]
            if letter == guess:
                right_guess += 1
                display[position] = letter
        print(f"All the guesses you made so far: {all_guesses}")
        if not right_guess:
            lives = lives - 1
            print(f"The letter {guess}, is not in the word, so you lose a life.")

        print(stages.stages[lives])

        if lives != 0:
            print(f"{' '.join(display)}")

        if lives == 0:
            game_end = True
            print("You Lose:")
            display = chosen_word
            print(f"The word was {display}")

        if "_" not in display:
            game_end = True
            if lives != 0:
                print("Well Done, You Win.")