def rps_code():
    import random
    print(" ---- Rock Paper Scissors Game ----")
    rock = '''
        _______
    ---'   ____)
          (_____)
          (_____)
          (____)
    ---.__(___)
    '''

    paper = '''
        _______
    ---'   ____)____
              ______)
              _______)
             _______)
    ---.__________)
    '''

    scissors = '''
        _______
    ---'   ____)____
              ______)
           __________)
          (____)
    ---.__(___)
    '''
    items = [rock, paper, scissors]
    user_pick = (input("Type 1 for rock, 2 for paper, 3 for scissors: "))
    r_o_s = int(user_pick) - 1
    if r_o_s == 0:
        print(items[0])
    elif r_o_s == 1:
        print(items[1])
    elif r_o_s == 2:
        print(items[2])
    else:
        print("Only type 0, 1 or 2")
    bot_pick = random.randint(0, 2)
    print("Bot picks:")
    if bot_pick == 0:
        print(items[0])
    elif bot_pick == 1:
        print(items[1])
    elif bot_pick == 2:
        print(items[2])

    if bot_pick == 0 and r_o_s == 2:
        print("You lose")
    elif bot_pick == 1 and r_o_s == 0:
        print("You lose")
    elif bot_pick == 2 and r_o_s == 1:
        print("You lose")
    elif bot_pick == r_o_s:
        print("You draw")
    else:
        print("You win")